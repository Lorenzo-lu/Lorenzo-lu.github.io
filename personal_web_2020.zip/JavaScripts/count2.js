
var countEL = parseInt(document.getElementById('count').innerHTML);
//document.write(countEL)
countEL += 1;
document.getElementById('count').innerHTML = countEL;
